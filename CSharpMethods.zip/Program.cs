﻿// See https://aka.ms/new-console-template for more information
using System;
class Program
{
    static void MyMethod()
    {
        Console.WriteLine("Wanna check the day of the week?");
        Console.WriteLine("---------------------------------");
    }
    static void CheckWeek()
    {
        Console.WriteLine("Enter day of week");
        int date = Convert.ToInt32((Console.ReadLine()));
        switch (date)
        {
            case 1:
                Console.WriteLine("Sunday");
                break;
            
            case 2:
                Console.WriteLine("Monday");
                break;

            case 3:
                Console.WriteLine("Tuesday");
                break ;
           
            case 4:
                Console.WriteLine("Wednesday");
                break;;

            case 5:
                Console.WriteLine("Thursday");
                break;

            case 6:
                Console.WriteLine("Friday");
                Console.WriteLine("It's almost weekend now, keep it up!");
                break;

            case 7:
                Console.WriteLine("Saturday");
                Console.WriteLine("Yay! It's weekend now!");
                break;

                default:
                Console.WriteLine("Invalid");
                break;
        }
    }

    static void ForLoop()
    {
        for (int i = 0; i < 10; i++)
            if (i % 10 == 0)
                Console.WriteLine("Hello!");
            else
                Console.WriteLine("Hi!");
    }

    static void Main(string[] args)
    {
        MyMethod();
        CheckWeek();
        ForLoop();
    }
}